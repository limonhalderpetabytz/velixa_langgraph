import os
from langchain_core.vectorstores import FAISS
from langchain_core.embeddings import OpenAIEmbeddings
from langchain_openai import ChatOpenAI



class KnowledgeBaseTool:
    """
    Self-contained FAISS knowledge base tool.
    Provides retrieval and persistent storage of problem-solution pairs.
    """

    def __init__(self, faiss_dir="tools/faiss_store"):
        self.faiss_dir = faiss_dir
        self.embeddings = OpenAIEmbeddings()
        self.llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.3)

        # Load existing FAISS or create new
        if os.path.exists(os.path.join(faiss_dir, "index.faiss")):
            print("📂 Loading existing FAISS KB...")
            self.vectorstore = FAISS.load_local(
                faiss_dir, self.embeddings, allow_dangerous_deserialization=True
            )
        else:
            print("🆕 Creating new FAISS KB...")
            os.makedirs(faiss_dir, exist_ok=True)
            self.vectorstore = FAISS.from_texts([], self.embeddings, metadatas=[])

    def add_solution(self, query: str, solution: str):
        """
        Add or update a problem-solution pair
        """
        self.vectorstore.add_texts([query], [{"solution": solution}])
        self.vectorstore.save_local(self.faiss_dir)

    def retrieve_solution(self, query: str, threshold: float = 0.75):
        """
        Retrieve a solution from FAISS KB if similarity >= threshold
        """
        docs_and_scores = self.vectorstore.similarity_search_with_score(query, k=1)
        if docs_and_scores:
            doc, score = docs_and_scores[0]
            if score >= threshold:
                return doc.metadata.get("solution", None)
        return None

# ==============================================
# 📘 user_solution_node.py — Fully Autonomous Self-Learning Node
# ==============================================
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.runnables import RunnableConfig
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from .user_tool import user_tools
import os


# ---------------------------------------------------
# 🧠 Environment Setup
# ---------------------------------------------------
load_dotenv(dotenv_path=".env", override=True)
api_key = os.getenv("OPENAI_API_KEY")
os.environ["OPENAI_API_KEY"] = api_key

# ---------------------------------------------------
# 🧩 Knowledge Base Tools
# ---------------------------------------------------
kb_tool = KnowledgeBaseTool()

@tool
def retrieve_solution(query: str) -> str:
    solution = kb_tool.retrieve_solution(query)
    if solution:
        return f"✅ Found in Knowledge Base:\n{solution}"
    return None

@tool
def generate_solution(query: str, memory: str = "None") -> str:
    """
    Generate solution using LLM when KB does not have an answer.
    """
    llm_solution = ChatOpenAI(model_name="gpt-4", temperature=0.2)
    prompt = f"""
You are a professional problem-solving assistant. The user asked:

User Query: {query}

Memory context: {memory}

Provide a clear, concise, and practical solution for the user.

💡 Generated Solution:
"""
    response = llm_solution.invoke([SystemMessage(prompt)])
    return response.content.strip()

@tool
def confirm_and_update_solution(query: str, solution: str, user_confirmed: bool) -> str:
    """
    Update KB with solution only after user confirms it worked.
    """
    if user_confirmed:
        kb_tool.add_solution(query, solution)
        return f"💾 Solution confirmed and added to KB:\n{solution}"
    else:
        return "⚠️ Solution not confirmed. KB not updated."

# ---------------------------------------------------
# Bind ServiceNow tools + KB tools
# ---------------------------------------------------
solution_tools =[retrieve_solution, generate_solution, confirm_and_update_solution]